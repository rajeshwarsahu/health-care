document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.querySelector(".login-form");
  const closeIcon = document.querySelector(".icon-close");
  const loginButton = document.querySelector(".btn");

  closeIcon.addEventListener("click", function () {
    loginForm.style.display = "none";
  });

  loginButton.addEventListener("click", function (event) {
    event.preventDefault(); // Prevent the default link behavior

    // Redirect to chatbot.html
    window.location.href = "chatbot.html";
  });
});
