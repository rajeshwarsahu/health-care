const chatInput = document.querySelector(".chat-input textarea");
const sendChatBtn = document.querySelector(".chat-input span");
const chatbox = document.querySelector(".chatbox");
const chatbotToggler = document.querySelector(".chatbot-toggler");
const chatbotCloseBtn = document.querySelector(".close-btn");
const medicineReminder = document.querySelector(".medicine-reminder");
const reminderList = document.querySelector(".reminder-list");
const medicineNameInput = document.getElementById("medicine-name");
const medicineTimeInput = document.getElementById("medicine-time");
const addReminderBtn = document.getElementById("add-reminder-btn");

let userMessage;
const API_KEY = "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";

const createChatLi = (message, className) => {
  const chatLi = document.createElement("li");
  chatLi.classList.add("chat", className);
  let chatContent =
    className === "outgoing"
      ? `<p>${message}</p>`
      : `<span class="icon"><ion-icon name="logo-reddit"></ion-icon></span><p>${message}</p>`;
  chatLi.innerHTML = chatContent;
  return chatLi;
};

const scrollToBottom = () => {
  chatbox.scrollTop = chatbox.scrollHeight;
};

const generateResponse = async () => {
  const API_URL = "https://api.openai.com/v1/chat/completions";
  const thinkingMessage = createChatLi("Thinking...", "incoming");

  chatbox.appendChild(thinkingMessage);
  scrollToBottom();

  const requestOptions = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${API_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: userMessage }],
    }),
  };

  try {
    const response = await fetch(API_URL, requestOptions);
    if (!response.ok) {
      throw new Error(`Request failed with status: ${response.status}`);
    }
    const data = await response.json();
    const responseMessage = data.choices[0].message.content;

    chatbox.removeChild(thinkingMessage);

    chatbox.appendChild(createChatLi(responseMessage, "incoming"));
    scrollToBottom();
  } catch (error) {
    console.log(error);
    chatbox.appendChild(createChatLi("Oops! Something went wrong.", "incoming"));
    scrollToBottom();
  }
};

const handleChat = () => {
  userMessage = chatInput.value.trim();
  if (!userMessage) return;

  chatbox.appendChild(createChatLi(userMessage, "outgoing"));
  chatInput.value = "";

  setTimeout(() => {
    generateResponse();
  }, 600);
};

chatbotCloseBtn.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));

sendChatBtn.addEventListener("click", handleChat);

chatInput.addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = this.scrollHeight + "px";
});

window.addEventListener("offline", () => {
  chatbox.appendChild(createChatLi("No internet connection.", "incoming"));
  scrollToBottom();
});

window.addEventListener("online", () => {
  chatbox.appendChild(createChatLi("Internet connection restored.", "incoming"));
  scrollToBottom();
});

// Function to request notification permission
const requestNotificationPermission = () => {
  if (Notification.permission !== "granted") {
    Notification.requestPermission().then((permission) => {
      if (permission === "granted") {
        console.log("Notification permission granted.");
      }
    });
  }
};

// Function to send a push notification
const sendPushNotification = (medicineName, medicineTime) => {
  if (Notification.permission === "granted") {
    const notification = new Notification("Medicine Reminder", {
      body: `It's time to take your ${medicineName} at ${medicineTime}`,
      icon: "img/notification.jpg", // Replace with your icon path
    });

    notification.onclick = () => {
      // Handle click event if needed
    };
  }
};

// Request notification permission when the page loads
requestNotificationPermission();

const addReminder = () => {
  const medicineName = medicineNameInput.value;
  const medicineTime = medicineTimeInput.value;

  if (!medicineName || !medicineTime) {
    alert("Please enter both medicine name and time.");
    return;
  }

  const reminderItem = document.createElement("li");
  reminderItem.innerHTML = `
    <span>${medicineName}</span>
    <span>${medicineTime}</span>
  `;

  reminderList.appendChild(reminderItem);

  // Send push notification
  sendPushNotification(medicineName, medicineTime);

  // Clear input fields
  medicineNameInput.value = "";
  medicineTimeInput.value = "";
};

addReminderBtn.addEventListener("click", addReminder);
