const loginform = document.querySelector('.login-form');
const loginlink = document.querySelector('.login-link');
const registerlink = document.querySelector('.register-link');

registerlink.addEventListener('click',()=>{
    loginform.classList.add('active')});

    loginlink.addEventListener('click',()=>{
        loginform.classList.remove('active')});
    