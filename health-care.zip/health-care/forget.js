document.addEventListener("DOMContentLoaded", function () {
  const loginForm = document.querySelector(".login-form");
  const closeIcon = document.querySelector(".icon-close");
  const form = document.querySelector("form");
  const passwordResetSuccess = document.getElementById("passwordResetSuccess");

  form.addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent the form from actually submitting

    // Simulate a successful password reset (you can replace this with your actual logic)
    const resetSuccessful = true;

    if (resetSuccessful) {
      passwordResetSuccess.style.display = "block"; // Show the success message
      // You can also redirect the user to another page or perform other actions here
    }
  });

  closeIcon.addEventListener("click", function () {
    loginForm.style.display = "none";
  });
});
